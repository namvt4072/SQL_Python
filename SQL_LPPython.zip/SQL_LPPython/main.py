from src.utils import MNISTImage, save_mnist_image, get_mnist_images, ImageLog, save_image_log, get_image_logs

if __name__ == "__main__":
    # Lưu ảnh mẫu
    img = MNISTImage(None, '[0,255,128,64,32]', 1, 1, None)
    save_mnist_image(img)
    
    # Lưu log thao tác
    log = ImageLog(None, 1, 1, 'upload', None)
    save_image_log(log)
    
    # Đọc và in danh sách ảnh
    images = get_mnist_images()
    for image in images:
        print(f"ID: {image.image_id}, LabelID: {image.label_id}, UserID: {image.user_id}, Pixels: {image.pixels}")

    # Đọc và in log
    logs = get_image_logs()
    for l in logs:
        print(f"LogID: {l.log_id}, ImageID: {l.image_id}, UserID: {l.user_id}, Action: {l.action}, Time: {l.log_time}")