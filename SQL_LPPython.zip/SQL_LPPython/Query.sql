-- Tạo database nếu chưa có
IF DB_ID('SQL_Python') IS NULL
    CREATE DATABASE SQL_Python;
GO

USE SQL_Python;
GO

-- Bảng người dùng (Users)
IF OBJECT_ID('Users', 'U') IS NULL
BEGIN
    CREATE TABLE Users (
        user_id INT IDENTITY(1,1) PRIMARY KEY,
        username NVARCHAR(50) UNIQUE NOT NULL,
        email NVARCHAR(100) NOT NULL,
        created_at DATETIME DEFAULT GETDATE()
    );
END
GO

-- Bảng nhãn ảnh (ImageLabels)
IF OBJECT_ID('ImageLabels', 'U') IS NULL
BEGIN
    CREATE TABLE ImageLabels (
        label_id INT IDENTITY(1,1) PRIMARY KEY,
        label_value INT NOT NULL,
        description NVARCHAR(100)
    );
END
GO

-- Bảng lưu ảnh MNIST
IF OBJECT_ID('MNISTImages', 'U') IS NULL
BEGIN
    CREATE TABLE MNISTImages (
        image_id INT IDENTITY(1,1) PRIMARY KEY,
        pixels NVARCHAR(MAX) NOT NULL,
        label_id INT,
        user_id INT,
        upload_time DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (label_id) REFERENCES ImageLabels(label_id),
        FOREIGN KEY (user_id) REFERENCES Users(user_id)
    );
END
GO

-- Bảng log thao tác trên ảnh
IF OBJECT_ID('ImageLogs', 'U') IS NULL
BEGIN
    CREATE TABLE ImageLogs (
        log_id INT IDENTITY(1,1) PRIMARY KEY,
        image_id INT NOT NULL,
        user_id INT NOT NULL,
        action NVARCHAR(50) NOT NULL, -- upload/update/delete
        log_time DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (image_id) REFERENCES MNISTImages(image_id),
        FOREIGN KEY (user_id) REFERENCES Users(user_id)
    );
END
GO

-- Thêm dữ liệu mẫu
IF NOT EXISTS (SELECT 1 FROM ImageLabels)
BEGIN
    INSERT INTO ImageLabels (label_value, description) VALUES (0, N'Số 0');
    INSERT INTO ImageLabels (label_value, description) VALUES (1, N'Số 1');
    INSERT INTO ImageLabels (label_value, description) VALUES (2, N'Số 2');
    INSERT INTO ImageLabels (label_value, description) VALUES (3, N'Số 3');
    INSERT INTO ImageLabels (label_value, description) VALUES (4, N'Số 4');
    INSERT INTO ImageLabels (label_value, description) VALUES (5, N'Số 5');
    INSERT INTO ImageLabels (label_value, description) VALUES (6, N'Số 6');
    INSERT INTO ImageLabels (label_value, description) VALUES (7, N'Số 7');
    INSERT INTO ImageLabels (label_value, description) VALUES (8, N'Số 8');
    INSERT INTO ImageLabels (label_value, description) VALUES (9, N'Số 9');
END
GO

IF NOT EXISTS (SELECT 1 FROM Users)
BEGIN
    INSERT INTO Users (username, email) VALUES ('namvt', 'namvt@example.com');
    INSERT INTO Users (username, email) VALUES ('linhpt', 'linhpt@example.com');
END
GO

-- Dữ liệu mẫu MNISTImages và ImageLogs
INSERT INTO MNISTImages (pixels, label_id, user_id) VALUES 
(N'[0,255,34,12,67,89,255]', 1, 1),
(N'[12,255,99,45,255,76,128]', 2, 2),
(N'[255,0,0,0,255,130,45]', 3, 1);
GO

INSERT INTO ImageLogs (image_id, user_id, action) VALUES
(1, 1, 'upload'),
(2, 2, 'upload'),
(3, 1, 'upload');
GO

select * from MNISTImages;
select * from ImageLabels;
select * from Users;    