class User:
    def __init__(self, user_id, username, email, created_at):
        self.user_id = user_id
        self.username = username
        self.email = email
        self.created_at = created_at

class ImageLabel:
    def __init__(self, label_id, label_value, description):
        self.label_id = label_id
        self.label_value = label_value
        self.description = description

class MNISTImage:
    def __init__(self, image_id, pixels, label_id, user_id, upload_time):
        self.image_id = image_id
        self.pixels = pixels
        self.label_id = label_id
        self.user_id = user_id
        self.upload_time = upload_time

class ImageLog:
    def __init__(self, log_id, image_id, user_id, action, log_time):
        self.log_id = log_id
        self.image_id = image_id
        self.user_id = user_id
        self.action = action
        self.log_time = log_time

import pyodbc
from config.settings import CONFIG

def get_connection():
    conn_str = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={CONFIG['db_server']};"
        f"DATABASE={CONFIG['db_name']};"
        f"UID={CONFIG['db_user']};"
        f"PWD={CONFIG['db_password']};"
    )
    return pyodbc.connect(conn_str)

def save_mnist_image(image: MNISTImage):
    conn = get_connection()
    cursor = conn.cursor()
    sql = "INSERT INTO MNISTImages (pixels, label_id, user_id) VALUES (?, ?, ?)"
    cursor.execute(sql, str(image.pixels), image.label_id, image.user_id)
    conn.commit()
    conn.close()

def save_image_log(log: ImageLog):
    conn = get_connection()
    cursor = conn.cursor()
    sql = "INSERT INTO ImageLogs (image_id, user_id, action) VALUES (?, ?, ?)"
    cursor.execute(sql, log.image_id, log.user_id, log.action)
    conn.commit()
    conn.close()

def get_mnist_images():
    conn = get_connection()
    cursor = conn.cursor()
    sql = "SELECT image_id, pixels, label_id, user_id, upload_time FROM MNISTImages"
    cursor.execute(sql)
    images = []
    for row in cursor.fetchall():
        img = MNISTImage(row.image_id, row.pixels, row.label_id, row.user_id, row.upload_time)
        images.append(img)
    conn.close()
    return images

def get_image_logs():
    conn = get_connection()
    cursor = conn.cursor()
    sql = "SELECT log_id, image_id, user_id, action, log_time FROM ImageLogs"
    cursor.execute(sql)
    logs = []
    for row in cursor.fetchall():
        log = ImageLog(row.log_id, row.image_id, row.user_id, row.action, row.log_time)
        logs.append(log)
    conn.close()
    return logs